#define MAX 8
#include "logic.h"

void func_1s_comp(int a[], int result[]){
	func_not(a, result);
}
