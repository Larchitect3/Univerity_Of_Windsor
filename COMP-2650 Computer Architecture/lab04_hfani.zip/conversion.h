#ifndef CONVERT_TOOLS_H_
#define CONVERT_TOOLS_H_


void to_octal(int a[]);



#endif /* CONVERT_TOOLS_H_ */
