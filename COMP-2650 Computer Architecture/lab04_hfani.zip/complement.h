#ifndef COMP_TOOLS_H_
#define COMP_TOOLS_H_

void func_1s_comp(int a[], int result[]);

#endif /* COMP_TOOLS_H_ */
