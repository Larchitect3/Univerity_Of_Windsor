#define MAX 8

void to_octal(int a[]){
	//To do
}

