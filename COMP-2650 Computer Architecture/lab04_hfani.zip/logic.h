#ifndef LOGIC_TOOLS_H_
#define LOGIC_TOOLS_H_

void func_and(int a[], int b[], int result[]);
void func_not(int a[], int result[]);


#endif /* LOGIC_TOOLS_H_ */
